<div class="alert alert-info text-center mt-sm-2 mb-sm-2">
    لطفا برای فعال شدن ناحیه کاربری از بخش <a class="btn-blue mx-2 d-sm-block"
                                              href="{{ route('home.users_profile.index') }}">اطلاعات
        حساب کاربری</a> مشخصات خود را تکمیل نمایید.
</div>
